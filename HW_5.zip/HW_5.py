#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   DRedmond, 03/10/2019, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

# Step 1
# create the ToDO text file
# load the beginning values into the text file
HW_5File = open("ToDo.txt","w")
HW_5File.write("clean house\n")
HW_5File.write("low\n")
HW_5File.write("pay bills\n")
HW_5File.write("high\n")

# open and read the file
HW_5File = open("ToDo.txt", "r")

# convert the data in the text file to a Python list
ToDoList = []
for line in HW_5File:
    ToDoList.append(line)

# open the file in a writeable format so data can be saved to it later
HW_5File = open("ToDo.txt", "w")

# take the list data that was imported from the text file and convert them to keys and values
# also strip out the new line inidicator \n
ToDoListKeys = (ToDoList[0].rstrip(None),ToDoList[2].rstrip(None))
ToDoListValues = (ToDoList[1].rstrip(None), ToDoList[3].rstrip(None))

# use the list(zip()) method to convert to a Tuple
ToDoTuple = list(zip(ToDoListKeys,ToDoListValues))

# convert the Tuple to a Dictionary
ToDoDict = dict(ToDoTuple)

# Step 2
# interaction with the user that allows the user to alter the dictionary
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print(ToDoDict)

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        newTask = input("What task would you like to add?: ")
        if newTask.lower() not in ToDoDict:
            newPriority = input("\nWhat's the priority of this new task?: ")
            ToDoDict[newTask] = newPriority
            print("The new task of", newTask, "has been added!")
        else:
            print("\nThat task is already on the list.")
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        removeTask = input("What task would you like to remove?: ")
        if removeTask.lower() in ToDoDict:
            del ToDoDict[removeTask.lower()]
            print("\nThe task", removeTask, "has been removed from the To Do List.")
        else:
            print("\nThat task is not on the To Do List.")

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        NewToDoListKeys = list(ToDoDict.keys())
        NewToDoListValues = list(ToDoDict.values())
        NewToDoTable = (NewToDoListKeys, NewToDoListValues)
        HW_5File.write(str(NewToDoTable))
        print("Your data has been saved!")
        HW_5File.close()
    elif (strChoice == '5'):
        break #and Exit the program












